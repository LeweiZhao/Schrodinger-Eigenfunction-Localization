function A=eigannulus(N,R0,R)
A=zeros(N,N);
for n=1:N
    for k=1:N
        A(n,k)=eigann(n,k,R0,R);
    end
end
A;