function [r]=NewtonAnnR(n,x0,R)
dx=1;
x=x0;
while abs(dx)>10^(-8)
    F=besselj(n,x)*bessely(n,R*x)-besselj(n,R*x)*bessely(n,x);
    J1=dbesselj(n,x)*bessely(n,R*x)+R*besselj(n,x)*dbessely(n,R*x);
    J2=R*dbesselj(n,R*x)*bessely(n,x)+besselj(n,R*x)*dbessely(n,x);
    JF=J1-J2;
    dx=F/JF;
    x=x-dx;
end
r=x;