function [r]=NewtonAnn(n,x0,R0)
dx=1;
x=x0;
while abs(dx)>10^(-8)
    F=besselj(n,R0*x)*bessely(n,x)-besselj(n,x)*bessely(n,R0*x);
    J1=R0*dbesselj(n,R0*x)*bessely(n,x)+besselj(n,R0*x)*dbessely(n,x);
    J2=dbesselj(n,x)*bessely(n,R0*x)+R0*besselj(n,x)*dbessely(n,R0*x);
    JF=J1-J2;
    dx=F/JF;
    x=x-dx;
end
r=x;