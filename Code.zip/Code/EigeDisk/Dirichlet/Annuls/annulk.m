function annulk(n,k,K,N,R0)
% Graph of modes when n is not 0 and k is fixed
% K is the number of a_nk that you want to rearrange,eg K=51
% N is the number of nodes of polar grids, eg N=1000
% R0 is the inner radius, eg R0=0.5, and outer radius is 1
% The final index is l=1
A0=linspace(0,2*pi,N+1);
A1=n*A0(1:N);
A=cos(A1);
for i=1:K
    [xa(i),xc(i)]=annulac(i,k,R0,1);
    % Use Newton Iteration Method to solve a_nk and c_nk
end
[ra,ia,ja]=unique(xa);
% Rearrange a_nk
a=ra(n+1);
% Select nth a_nk since n starts from 0
rc=ia(n+1);
% The orginal n index of a_nk
c=xc(rc);
% The coresponding c_nk
Z=zeros(N);
for i=1:N
    Z(i,:)=(besselj(n,a*(1-(1-R0)*(i-1)/(N-1)))+c*bessely(n,a*(1-(1-R0)*(i-1)/(N-1))))*A;
end
polar3d(Z,0,2*pi,R0,1,1)
title('n=?,k=?')
    