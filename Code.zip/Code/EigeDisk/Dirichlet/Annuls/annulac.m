function [a,c]=annulac(n,k,R0,R)
% Use Newton Iteration Method to solve the equations by Dirichlet Condition
% on annuls R0 is inner radius and R is outer radius
a0=besselzero(n,k,1);
% Get the zeros of Bessel function of first kind
a=a0(end);
r=R0/R;
c=0;
x=[a;c];
% Use values of situation on disk as initial value of Newton Interation
e=1;
while e>10^(-8)
    a=x(1);
    c=x(2);
    a1=r*a;
    Ja=besselj(n,a);
    Ya=bessely(n,a);
    Ja1=besselj(n,a1);
    Ya1=bessely(n,a1);
    F=[Ja+c*Ya;Ja1+c*Ya1];
    % Left side of equations
    dJa=dbesselj(n,a);
    dYa=dbessely(n,a);
    dJa1=dbesselj(n,a1);
    dYa1=dbessely(n,a1);
    J=[dJa+c*dYa Ya;r*dJa1+c*r*dYa1 Ya1];
    % Jaccobi Matrix
    dx=-J\F;
    e=norm(dx,inf);
    x=x+dx;
end
a=x(1);
c=x(2);