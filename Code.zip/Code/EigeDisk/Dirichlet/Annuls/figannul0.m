function figannul0(k,R0,N)
A=Annul(0,R0);
ak=A(k);
c=-besselj(0,ak)/bessely(0,ak);
Z=zeros(N);
for i=1:N
    Z(i,:)=-(besselj(0,ak*(1-(1-R0)*(i-1)/(N-1)))+c*bessely(0,ak*(1-(1-R0)*(i-1)/(N-1))));
end
polar3d(Z,0,2*pi,R0,1,1);
%title('n=0,k=1')