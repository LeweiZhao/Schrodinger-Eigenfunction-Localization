function annul0k(k,K,N,R0)
% Graph of modes on annuls when n=0 and outer radius is 1
% K is the number of roots that you want to rearrange,eg K=50
% N is the number of nodes of polar grids,eg N=1000
%R0 is the inner radius, eg R0=0.5
for i=1:K
    [xa(i),xc(i)]=annulac(0,i,R0,1);
    % Use Newton Iteration Method to solve equtions on boundary
end
[ra,ia,ja]=unique(xa);
% Rearrange as ascending order by a_0k 
a=ra(k);
% Select kth a_0k
rc=ia(k);
% the orignal k index of c_0k
c=xc(rc);
% consponding c_0k
Z=zeros(N);
for i=1:N
    Z(i,:)=(besselj(0,a*(1-(1-R0)*(i-1)/(N-1)))+c*bessely(0,a*(1-(1-R0)*(i-1)/(N-1))));
end
polar3d(Z,0,2*pi,R0,1,1)
title('n=0,k=?')