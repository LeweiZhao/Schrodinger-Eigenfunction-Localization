function A=Annul(n,R0)
X=[1:1:100000];
F=besselj(n,R0*X).*bessely(n,X)-besselj(n,X).*bessely(n,R0*X);
%plot(X,F)
P=find(F>0);
N=find(F<0);
M=length(P);
K0=[];
for i=1:M-1
    if P(i+1)-P(i)>1
        K0=[K0,P(i)];
    end
end
Nk=length(K0);
a=zeros(1,Nk);
for j=1:Nk
    a(j)=NewtonAnn(n,K0(j),R0);
end
A=a;

