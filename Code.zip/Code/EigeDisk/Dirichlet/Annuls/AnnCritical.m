function AnnCritical(n,k,R,N)
A0=linspace(0,2*pi,N+1);
A1=n*A0(1:N);
A=cos(A1);

X=[1:1:10000];
F=besselj(n,X).*bessely(n,R*X)-besselj(n,R*X).*bessely(n,X);
%plot(X,F)
P=find(F>0);
M=length(P);
K0=[];
for i=1:M-1
    if P(i+1)-P(i)>1
        K0=[K0,P(i)];
    end
end
Nk=length(K0);
a=zeros(1,Nk);
for j=1:Nk
    a(j)=NewtonAnnR(n,K0(j),R);
end

ak=a(k);
c=-besselj(n,ak)/bessely(n,ak);
Z=zeros(N);
for i=1:N
    Z(i,:)=(besselj(n,ak*(R-(R-1)*(i-1)/(N-1)))+c*bessely(n,ak*(R-(R-1)*(i-1)/(N-1))))*A;
end
Z(N-300:N,:)=0;
polar3d(Z,0,2*pi,1,R,1);