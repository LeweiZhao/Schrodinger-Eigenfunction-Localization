function figAnnulnk(n,k,R0,N)
A0=linspace(0,2*pi,N+1);
A1=n*A0(1:N);
A=cos(A1);
a=Annul(n,R0);
ak=a(k);
c=-besselj(n,ak)/bessely(n,ak);
Z=zeros(N);
for i=1:N
    Z(i,:)=(besselj(n,ak*(1-(1-R0)*(i-1)/(N-1)))+c*bessely(n,ak*(1-(1-R0)*(i-1)/(N-1))))*A;
end
Z(N-100:N,:)=0;
polar3d(Z,0,2*pi,R0,1,1);
%title('n=?,k=?')