function annuln(n1,k,K,N,R0)
% Graph of modes on annuls when n is not 0 and outer radius is 1.
% And n is fixed as n1
% K is the number of a_nk that you want to rearrange, eg K=51
% N is the number of nodes of polar grid, eg N=1000
% R0 is the inner radius, eg R0=0.5
% The final index l=1
A0=linspace(0,2*pi,N+1);
A1=n1*A0(1:N);
A=cos(A1);
for n=1:K
    [xa(n),xc(n)]=annulac(n1,n,R0,1);
    %Use Newton Iteration Method to solve equations on boundary 
end
[ra,ia,ja]=unique(xa);
% Rearrange a_nk
a=ra(k);
% Selected kth a_nk
rc=ia(k);
% The orignal k index of a_nk
c=xc(rc);
% The corresponing c_nk
Z=zeros(N);
for i=1:N
    Z(i,:)=(besselj(n1,a*(1-(1-R0)*(i-1)/(N-1)))+c*bessely(n1,a*(1-(1-R0)*(i-1)/(N-1))))*A;
end
polar3d(Z,0,2*pi,R0,1,1)
title('n=?,k=?')
    