function sector(n,k,b,N)
% Graph of Modes on sector when n is not zero
% N is number of nodes in polar grids,eg N=1000
% b*pi is the angle
A0=linspace(0,b*pi,N+1);
A1=n*b*A0(1:N);
B=sin(A1);
a0=besselzero(b*n,k,1);
% get zeros of Bessel function of first kind and the order is b*n
a=a0(end);
Z1=zeros(N);
for i=1:N
    Z1(i,:)=besselj(b*n,a*(N-i)/N)*B;
end
polar3d(Z1,0,b*pi,0,1,1)
title('n=?,k=?')