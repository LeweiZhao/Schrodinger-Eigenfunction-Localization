function EigenDistri
N=20;
A=zeros(N);
for i=1:N
    A(i,:)=besselzero(i-1,N,1);
end
[a,b]=unique(A);
l=mod(b,N);
d=find(l==0);
l(d)=N;
k=ceil(b/N);
plot(l,k)
xlabel('n')
ylabel('k')
