function LapTest
figure

subplot(2,3,1)
figdisk(20,2,1000)
title('n=20,k=2')

subplot(2,3,2)
figdisk(50,5,1000)
title('n=50,k=5')

subplot(2,3,3)
figdisk(200,20,1000)
title('n=200,k=20')

subplot(2,3,4)
figdisk(500,50,1000)
title('n=500,k=50')

subplot(2,3,5)
figdisk(1000,100,1000)
title('n=1000,k=100')

subplot(2,3,6)
figdisk(1500,150,1000)
title('n=1500,k=150')