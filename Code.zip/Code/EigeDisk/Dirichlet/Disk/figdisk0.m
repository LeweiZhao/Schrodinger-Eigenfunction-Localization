function figdisk0(k,N)
% Graph of Lapalace modes on disk when n=0
% N is numbers of nodes in polar axis grid, eg N=1000 
%a0=besselzero(0,k,1);
a0=besselzero(0,k,2);
% Solve the zeros of Bessel function
a=a0(end);
Z=zeros(N);
for i=1:N
    %Z(i,:)=besselj(0,a*(N-i)/N);
    Z(i,:)=bessely(0,a*(N-i)/N);
end
polar3d(Z,0,2*pi,0,1,1)
% Use Polar axis to graph
title('Lapalace n=0,k=1 BesselY')