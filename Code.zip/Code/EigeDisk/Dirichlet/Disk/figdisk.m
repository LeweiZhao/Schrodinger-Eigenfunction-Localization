function figdisk(n,k,N)
% Graph of Laplace Modes on disk when n is not zero
% N is numbers of nodes in polar grids,eg N=1000
% The final index l=1
A0=linspace(0,2*pi,N+1);
A1=n*A0(1:N);
A=cos(A1);
a0=besselzero(n,k,1);
% get zeros of Bessel function of first kind
a=a0(end);
Z=zeros(N);
for i=1:N
    Z(i,:)=besselj(n,a*(N-i)/N)*A;
end
polar3d(Z,0,2*pi,0,1,1);
title('n=?,k=?')