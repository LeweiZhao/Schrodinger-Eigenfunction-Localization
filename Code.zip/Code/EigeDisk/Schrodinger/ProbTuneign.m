function P1=ProbTuneign(c,n,N,P)
a01=diskeigen(c,n);
p=IntJL10eig(N,0,1,c,n,P);
q=IntJL10eig(N,0,c/a01,c,n,P);
P1=q/p;
