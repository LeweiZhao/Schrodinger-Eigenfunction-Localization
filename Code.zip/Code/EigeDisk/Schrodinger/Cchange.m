function [ck]=Cchange(c,k)
R0=linspace(10^(-6),0.5,1000);
C=zeros(1,1000);
for i=1:1000
A=SchAnnul(0,c,R0(i));
ak=A(k);
C(i)=-besselj(c,ak)/bessely(c,ak);
end
plot(R0,C)
