function [u]=solvetime(c,n,K,T,r)
A=zeros(K);
for i=1:K
    n=i-1;
    v=sqrt(c^2+n^2);
    % v is the order of Bessel function
    A(i,:)=besselzero(v,K,1).^2;
    % Find the zeros of Bessel functions
    % The square of zeros are eigenvalues
end

N=100;
h=1/N;
X=0:h:1;
[X0,W]=legslb(5);
S=0;
A=zeros(K,1);
for k=1:K
    for i=1:N
         Y=(X(i)+X(i+1)+h*X0)/2;
         % initial v=r(1-r)
         sw=W.*Y.*(1-Y).*besselj(v,a(k)*Y).*Y;
         s=sum(sw);
         S=S+s;
    end
    A(k)=h*S;
end
A=A./d;
U=exp(-a.^2*T).*A.*besselj(v,a*r);
u=sum(U);
        

