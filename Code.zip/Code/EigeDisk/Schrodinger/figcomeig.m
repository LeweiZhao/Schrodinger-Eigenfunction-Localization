function figcomeig
for n=1:4
    figtunceig(n)
    hold on
end
xlabel('c')
ylabel('Probability')
title(' Quantum Tunneling with respect to c for first 4 eigenvalues') 