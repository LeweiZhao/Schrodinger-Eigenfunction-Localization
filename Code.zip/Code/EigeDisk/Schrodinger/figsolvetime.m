function figsolvetime(c,T)
N=1000;
Z=zeros(N);
for i=1:N
    Z(i,:)=solvetime(c,2,100,T,(N-i)/N);
end
polar3d(Z,0,2*pi,0,1,1)
%title('c=0.5 T=0.1')