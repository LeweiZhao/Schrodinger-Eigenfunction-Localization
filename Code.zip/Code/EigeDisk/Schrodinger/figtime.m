function figtime(c)
figure
subplot(2,2,1)
figinitial
title('t=0')
subplot(2,2,2)
figsolvetime(c,0.01)
title('t=0.01')
subplot(2,2,3)
figsolvetime(c,0.1)
title('t=0.1')
subplot(2,2,4)
figsolvetime(c,0.5)
title('t=0.5')