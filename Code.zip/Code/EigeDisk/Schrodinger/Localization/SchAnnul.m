function A=SchAnnul(n,c,R0)
% Solve the zeros of crossing product
X=[1:1:1000];
v=sqrt(n^2+c^2);
F=besselj(v,R0*X).*bessely(v,X)-besselj(v,X).*bessely(v,R0*X);
%F=besselj(v,R0*X).*besselj(-v,X)-besselj(v,X).*besselj(-v,R0*X);
%plot(X,F)
P=find(F>0);
N=find(F<0);
M=length(P);
K0=[];
for i=1:M-1
    if P(i+1)-P(i)>1
        K0=[K0,P(i),P(i+1)];
    end
end
if P(1)>1
    K0=[P(1),K0];
end
Nk=length(K0);
%K0=K0*0.1;
a=zeros(1,Nk);
for j=1:Nk
    a(j)=SchNewtonAnn(n,c,K0(j),R0);
end
A=real(a);
%K=size(A,2);
%XK=1:K;
%plot(XK,A)
%hold on
%YK=pi/(1-R0)*XK;
%plot(XK,YK,'r')
