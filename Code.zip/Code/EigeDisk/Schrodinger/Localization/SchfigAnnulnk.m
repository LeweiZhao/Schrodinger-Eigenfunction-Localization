function SchfigAnnulnk(n,k,c,R0,N)
% Dr.Lewei Zhao, updated 08/20/2019
% Graph of Schrodinger modes on Annuls when l is nonzero 
% n is azimuthal quantum number (l in the paper ) and n is nonzero
% k is kth zeros of bessle function 
% R0 is inner radius and outer radius is fixed as 1
% c is paramter in the Schrodinger equation, eg c=1/2, 2/3
% N is numbers of nodes in polar axis grid, eg N=1000
v=sqrt(n^2+c^2);
A0=linspace(0,2*pi,N+1);
A1=n*A0(1:N);
A=cos(A1);
a=SchAnnul(n,c,R0);
ak=a(k);
ck=-besselj(v,ak)/bessely(v,ak);
%ck1=-besselj(v,ak*R0)/bessely(v,ak*R0)
Z=zeros(N);
for i=1:N
    Z(i,:)=(besselj(v,ak*(1-(1-R0)*(i-1)/(N-1)))+ck*bessely(v,ak*(1-(1-R0)*(i-1)/(N-1))))*A;
end
Z(N-300:N,:)=0;
polar3d(Z,0,2*pi,R0,1,1);