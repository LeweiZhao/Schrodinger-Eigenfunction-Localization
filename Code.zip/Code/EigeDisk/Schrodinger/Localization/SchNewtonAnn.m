function [r]=SchNewtonAnn(n,c,x0,R0)
dx=1;
x=x0;
v=sqrt(n^2+c^2);
while abs(dx)>10^(-8)
    F=besselj(v,R0*x)*bessely(v,x)-besselj(v,x)*bessely(v,R0*x);
    %F=besselj(v,R0*x)*besselj(-v,x)-besselj(v,x)*besselj(-v,R0*x);
    J1=R0*dbesselj(v,R0*x)*bessely(v,x)+besselj(v,R0*x)*dbessely(v,x);
    %J1=R0*dbesselj(v,R0*x)*besselj(-v,x)+besselj(v,R0*x)*dbesselj(-v,x);
    J2=dbesselj(v,x)*bessely(v,R0*x)+R0*besselj(v,x)*dbessely(v,R0*x);
    %J2=dbesselj(v,x)*besselj(-v,R0*x)+R0*besselj(v,x)*dbesselj(-v,R0*x);
    JF=J1-J2;
    dx=F/JF;
    x=x-dx;
end
r=x;