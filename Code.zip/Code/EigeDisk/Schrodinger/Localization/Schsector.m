function Schsector(n,k,c,b,N)
% Graph of Modes on sector when l is not zero
% n is azimuthal quantum number (l in the paper ) and n is nonzero
% k is kth zeros of bessle function 
% c is paramter in the Schrodinger equation, eg c=1/2, 2/3
% N is number of nodes in polar grids,eg N=1000
% b*pi is the angle
A0=linspace(0,b*pi,N+1);
A1=n*b*A0(1:N);
B=sin(A1);
v=sqrt(n^2+c^2);
a0=besselzero(b*v,k,1);
% get zeros of Bessel function of first kind and the order is b*n
a=a0(end);
Z1=zeros(N);
for i=1:N
    Z1(i,:)=besselj(b*v,a*(N-i)/N)*B;
end
polar3d(Z1,0,b*pi,0,1,1);
