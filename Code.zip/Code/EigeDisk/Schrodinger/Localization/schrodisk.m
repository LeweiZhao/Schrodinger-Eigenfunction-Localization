function schrodisk(n,k,c,N)
% Dr.Lewei Zhao, updated 08/20/2019
% Graph of Schrodinger modes on unit disk when l is nonzero
% n is azimuthal quantum number (l in the paper ) and n is nonzero
% k is kth zeros of bessle function 
% c is paramter in the Schrodinger equation, eg c=1/2, 2/3
% N is numbers of nodes in polar axis grid, eg N=1000 
b=sqrt(n^2+c^2);
a0=besselzero(b,k,1);
% Solve the zeros of Bessel function
a=a0(end);
A0=linspace(0,2*pi,N+1);
A1=n*A0(1:N);
A=cos(A1);
Z=zeros(N);
for i=1:N
    Z(i,:)=besselj(b,a*(N-i)/N)*A;
end
polar3d(Z,0,2*pi,0,1,1);
% Use Polar axis to graph
title('n=?,k=?,c=?')