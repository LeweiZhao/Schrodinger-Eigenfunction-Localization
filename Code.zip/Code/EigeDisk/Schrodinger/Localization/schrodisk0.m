function schrodisk0(k,c,N)
% Graph of Schrodinger modes on unit disk when l=0
% Dr.Lewei Zhao, updated 08/20/2019
% n is azimuthal quantum number (l in the paper ) and n is nonzero
% k is kth zeros of bessle function 
% c is paramter in the Schrodinger equation, eg c=1/2, 2/3
% N is numbers of nodes in polar axis grid, eg N=1000 
a0=besselzero(c,k,1);
% Solve the zeros of Bessel function
a=a0(end);
Z=zeros(N);
for i=1:N
    Z(i,:)=besselj(c,a*(N-i)/N);
end
polar3d(Z,0,2*pi,0,1,1);
% Use Polar axis to graph
%title('Schrodinger n=0,k=50,c=0.5 in X-Y View')