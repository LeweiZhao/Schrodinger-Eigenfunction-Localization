function figAnnul0(k,c,R0,N)
A=SchAnnul(0,c,R0);
ak=A(k);
ck=-besselj(c,ak)/bessely(c,ak);
%ck=-besselj(c,ak)/besselj(-c,ak);
Z=zeros(N);
for i=1:N
    Z(i,:)=((besselj(c,ak*(1-(1-R0)*(i-1)/(N-1)))+ck*bessely(c,ak*(1-(1-R0)*(i-1)/(N-1)))));
    %Z(i,:)=-(besselj(c,ak*(1-(1-R0)*(i-1)/(N-1)))+ck*besselj(-c,ak*(1-(1-R0)*(i-1)/(N-1))));
end
polar3d(Z,0,2*pi,R0,1,1);