function figtunceig(n)
C=linspace(0,2,40);
P=zeros(1,40);
for i=1:40
    P(i)=ProbTuneign(C(i),n,10^6,10);
end
%plot(C,P)
loglog(C,P)
%xlabel('c')
%ylabel('Probability')
%title(' Quantum Tunneling with respect to c for 4th eigenvalue') 