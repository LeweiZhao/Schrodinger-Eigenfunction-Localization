function [I]=IntJL10eig(N,a,b,c,n,P)
h=(b-a)/N;
T=a:h:b;
[X,W]=legslb(P);
an=diskeigen(c,n);
v=sqrt(c^2+n^2);
S=0;
for i=1:N
    Y=(T(i)+T(i+1)+h*X)/2;
    sw=W.*(besselj(v,an*Y).^2).*Y;
    s=sum(sw);
    S=S+s;
end
I=h*S/2;