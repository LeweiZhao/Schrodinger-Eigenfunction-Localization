function figinitial
N=1000;
Z=zeros(N);
for i=1:N
    Z(i,:)=(N-i)*i/(N^2);
end
polar3d(Z,0,2*pi,0,1,1)
%title('T=0')