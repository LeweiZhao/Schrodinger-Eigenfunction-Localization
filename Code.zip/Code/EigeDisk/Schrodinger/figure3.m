function figure3
figure
subplot(1,2,1)
schrodisk0(50,0.5,1000)
title('Schrodinger k=50 c=0.5')
subplot(1,2,2)
figdisk0(50,1000)
title('Laplace k=50')