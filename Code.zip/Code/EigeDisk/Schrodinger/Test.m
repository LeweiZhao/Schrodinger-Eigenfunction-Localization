function B=Test(N)
A=zeros(1,N);
for i=1:N
    A(i)=diskeigen(0.5,i,N);
end
B=A;