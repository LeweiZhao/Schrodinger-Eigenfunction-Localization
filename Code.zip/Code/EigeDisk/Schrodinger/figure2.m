function figure2
figure
subplot(2,2,1)
schrodisk0(1,0.5,1000)
title('Schrodinger k=1')
subplot(2,2,2)
figdisk0(1,1000)
title('Laplace k=1')
subplot(2,2,3)
schrodisk0(2,0.5,1000)
title('Schrodinger k=2')
subplot(2,2,4)
figdisk0(2,1000)
title('Laplace k=2')