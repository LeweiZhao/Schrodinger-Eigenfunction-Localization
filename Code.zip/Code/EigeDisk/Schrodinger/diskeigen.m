function [e]=diskeigen(c,n)
A=[];
for i=1:n
    v=sqrt(i^2+c^2);
    x=besselzero(v,i,1);
    A=[A;x];
end
B=unique(A);
e=B(n);