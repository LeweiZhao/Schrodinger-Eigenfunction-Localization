function Testincrease(n,d,c,delta,N)
v=sqrt(c^2+(n+d/2-1)^2);
up=v+delta;
Z=linspace(10^(-3),up,N);
F=Z.^(1-d/2).*dbesselj(v,Z)+(1-d/2)*Z.^(-d/2).*besselj(v,Z);
plot(Z,F)
