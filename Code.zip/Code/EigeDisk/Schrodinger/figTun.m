function figTun(a,b,N)
C=linspace(a,b,N);
P=zeros(1,N);
for i=1:N
    P(i)=ProbTun(C(i),10^6);
end
plot(C,P)
xlabel('c')
ylabel('Probability')
title(' Quantum Tunneling')    