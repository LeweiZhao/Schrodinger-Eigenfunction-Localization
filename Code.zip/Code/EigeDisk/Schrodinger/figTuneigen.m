function figTuneigen(K,N,p)
tic;
E=1:1:K;
P=zeros(1,K);
Q=P;
for i=1:K
    P(i)=ProbTuneign(0.5,i,N,p);
    Q(i)=ProbTuneign(2/3,i,N,p);
end
toc;
A=loglog(E,P,'r')
hold on 
B=loglog(E,Q,'b')
xlabel('eigenvalue')
ylabel('log-probablity')
title('Quantum Tunneling with respect to different eigenvalue')


