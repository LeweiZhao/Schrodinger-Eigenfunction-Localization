function testeiga(N,R0,R)
for n=1:N
  x(n)=eigann(n,1,R0,R);
end
x