function A=eigdisk(N)
A=zeros(N,N);
for i=1:N
    x=besselzero(i,N,1);
    A(:,i)=x.^2;
end
A;