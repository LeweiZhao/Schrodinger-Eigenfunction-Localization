function [vr]=Bifindomaina(c,K,E)
k=0;
a=0;
b=1;
while abs(b-a)>eps
      x = (a + b)/2;
if sign(SGMLadDisk(c,K,x)-1/E) == sign(SGMLadDisk(c,K,a)-1/E)
    a = x;
else
b = x;
end
k = k + 1;
end
vr=x;
k;