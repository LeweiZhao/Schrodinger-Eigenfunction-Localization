function [An]=consproduct(a,n)
A=1;
if n~=0

for i=1:n
  A=A*a;
  a=a+1;
end
An=A;
else
    An=1;
end