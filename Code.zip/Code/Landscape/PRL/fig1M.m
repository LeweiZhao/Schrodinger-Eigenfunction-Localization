function [DF]=fig1M(M,N)
V=unifrnd(0,8,1,M);
E=eye(M*N);
Z1=2*ones(M*N-1,1);
Z2=ones(M*N-2,1);
f=ones(M*N,1);
S=E-diag(Z1,-1)+diag(Z2,-2);
S(1,M*N-1)=1;
S(1,M*N)=-2;
S(2,M*N)=1;
VN=kron(V,ones(1,N));
d=VN(1:M*N-1);
for k=1:M-1
S(k*N+1,k*N-1)=-1;
S(k*N+1,k*N)=2;
S(k*N+1,k*N+1)=-1;
d(k*N)=0;
f((k-1)*N+1)=0;
end
f((M-1)*N+1)=0;
D=diag(d,-1);
K=-N^2*S+D;
Uh=K\f;
W=1./Uh;
X0=linspace(0,M,M*N+1);
X1=X0(2:end);
figure 
subplot(1,2,1)
plot(X1,VN)
axis([0 M 0 8])
ylabel('Potential')
subplot(1,2,2)
plot(X1,W);
axis([0 M 0 8])
ylabel('Effective Potential')
%E=eig(K);
%EV=sum(V);
%EW=sum(W)/N;
%DF=EV-EW;