function [W]=fig1B(M,N)
V0=unifrnd(0,8,1,M);
H=1;
%H=(2*9.10938356/6.62607004)*10^37;
V=V0*H;
Vs=V(2:M);
Vc=V(1:M-1);
d1=ones(1,M);
D1=diag(d1);
d1s=-exp(-sqrt(Vs));
D1s=diag(d1s,1);
A11=D1+D1s;
d2s=-exp(sqrt(Vs));
D2s=diag(d2s,1);
A12=D1+D2s;
d3=sqrt(V);
d3s=sqrt(Vs).*d1s;
D3=diag(d3);
D3s=diag(d3s,1);
A21=D3+D3s;
D4=diag(-d3);
d4s=sqrt(Vs).*exp(sqrt(Vs));
D4s=diag(d4s,1);
A22=D4+D4s;
A=[A11 A12;A21 A22];
f=zeros(2*M,1);
f(1:M-1)=1./Vs-1./Vc;
f(M)=1/V(1)-1/V(M);
C=A\f;
C=C';
c1=C(1:M);
c2=C(M+1:2*M);
X0=linspace(0,M,M*N+1);
U=zeros(1,M*N+1);
X=X0(1:M*N);
C1=kron(c1,ones(1,N));
C2=kron(c2,ones(1,N));
VN=kron(V0,ones(1,N));
VN0=kron(V0,ones(1,N));
EX=sqrt(VN);
k=1:1:M;
K=kron(k,ones(1,N));
u=C1.*exp(EX.*(X-K))+C2.*exp(-EX.*(X-K))+1./VN0;
U(1:M*N)=u;
U(end)=U(1);
W=1./U;
figure 
subplot(1,2,1)
plot(X,VN0)
axis([0 M 0 8])
ylabel('Potential')
subplot(1,2,2)
plot(X0,W);
axis([0 M 0 8])
ylabel('Effective Potential')
