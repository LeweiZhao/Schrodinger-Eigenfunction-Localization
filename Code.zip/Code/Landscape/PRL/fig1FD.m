function fig1FD(N)
V=unifrnd(0,8,1,2);
E=eye(2*N);
Z1=2*ones(2*N-1,1);
Z2=ones(2*N-2,1);
f=ones(2*N,1);
f(1)=0;
f(N+1)=0;
S=E-diag(Z1,-1)+diag(Z2,-2);
S(1,2*N-1)=1;
S(1,2*N)=-2;
S(2,2*N)=1;
S(N+1,N-1)=-1;
S(N+1,N)=2;
S(N+1,N+1)=-1;
v1=V(1);
v2=V(2);
V1=repmat(v1,1,N-1);
V2=repmat(v2,1,N-1);
d=[V1 0 V2];
D=diag(d,-1);
K=-N^2*S+D;
Uh=K\f;
W=1./Uh;
VN=kron(V,ones(1,N));
X0=linspace(0,2,2*N+1);
X1=X0(2:end);
figure 
subplot(1,2,1)
plot(X1,VN)
axis([0 2 0 8])
ylabel('Potential')
subplot(1,2,2)
plot(X1,W);
axis([0 2 0 8])
ylabel('Effective Potential')

