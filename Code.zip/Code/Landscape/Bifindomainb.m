function [vr]=Bifindomainb(c,K,E)
k=0;
a=0;
b=1;
while abs(b-a)>eps*abs(b)
      x = (a + b)/2;
if sign(SGMLadDisk(c,K,x)-1/E) == sign(SGMLadDisk(c,K,b)-1/E)
    b = x;
else
a = x;
end
k = k + 1;
end
vr=x;
k;