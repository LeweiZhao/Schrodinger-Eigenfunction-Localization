function Comp1ue(c,K,N)
h=1/N;
r=0.1:h:0.95;
u=SGMLadDisk(c,K,r);
W=1./u;
plot(r,W,'.r')
hold on
E1=besselzero(c,1,1)^2;
nE=length(r);
E=E1*ones(1,nE);
plot(r,E,'.b');
title('Comparsion of W=1/u and first eigenvalue c=0.5')
xlabel('r')
ylabel('value')