function Testroot
R=0:10^(-4):1;
U=SGMLadDisk(100,100,R);
NR=length(R);
%Um=max(U);
%Ea=fix(1/Um)+1000
%C=1/Ea*ones(NR,1);
plot(R,U)
title('sectional view of Landsacpe when c=100')
xlabel('r')
ylabel('U_K(r)')