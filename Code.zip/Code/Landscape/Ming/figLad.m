function figLad
figure
subplot(2,2,1)
figladDisk(0.5,1000,1000)
title('c=1/2 K=1000')
subplot(2,2,2)
figladDisk(2/3,1000,1000)
title('c=2/3 K=1000')
subplot(2,2,3)
figladDisk(100,1000,1000)
title('c=2/3 K=1000')
subplot(2,2,4)
Testroot