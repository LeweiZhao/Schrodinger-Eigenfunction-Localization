% Find the intergal interval of N_w(E) from initial value r0
% K is the truncation term of Landscape U_K(r)
function [vr]=findomain(c,K,E,r0)
dr=1;
r=r0;
% Newton interation method
while dr>10^(-14)
    F=SGMLadDisk(c,K,r)-1/E;
    JF=dSGMLadDisk(c,K,r);
    % Compute Jaccobi matrix
    dr=F/JF;
    r=r-dr;
end
vr=r;

% Derivative of Landscape U_K(r)
function [Jr]=dSGMLadDisk(c,K,r)
UK1=zeros(1,K);
UK2=zeros(1,K);
for k=1:K
    [da,a]=japoly(k-1,1,c,2*r^2-1);
    UK1(k)=(-1)^k*(2*k+c)*a/(k*(c/2+k-1)*(c/2+k)*(c/2+k+1));
    UK2(k)=(-1)^k*(2*k+c)*da/(k*(c/2+k-1)*(c/2+k)*(c/2+k+1));
end
Jr=c*((c*r^(c-1)*(r^2-1)+2*r^(c+1))/8*sum(UK1)+r^(c+1)*(r^2-1)/2*sum(UK2));

