% Figure for approximation of the Integrated Density of States N
% Lewei Zhao, Wayne State University
function figIDOS(c,K)
% c is the parameter in -\laplace u+ c^2/|x|^2u=\lambad u
% For example c=0.5 or c=2/3
% K is the number of eigenvalues 
% For example K=50,100?1000?
A=zeros(K);
for i=1:K
    n=i-1;
    v=sqrt(c^2+n^2);
    % v is the order of Bessel function
    A(i,:)=besselzero(v,K,1).^2;
    % Find the zeros of Bessel functions
    % The square of zeros are eigenvalues
end
B=unique(A);
% Rearrange the eigenvalues in increasing order
M=B(K);
% Find the largest eigenvalue
E=0:1:M;
% E are the nodes we will compute IDS N
NE=length(E);
for i=1:NE
    [I,J]=find(A<E(i));
    N=2*length(I);
    % Compute the IDS N
    plot(E(i),N,'.r')
    hold on
end
% Plot the IDS N
%R=0:10^(-3):1;
% R are the nodes we will compute Landscpae U_K(R)
%U=SGMLadDisk(c,100,R);
% Use Spectral-Gelarkin method solve the Landscape U_K(R) 
%Um=max(U);
%Ea=fix(1/Um)+1;
EW=0:1:M;
% EW are the nodes we will compute approximation N_W
NW=length(EW);
for j=1:NW
    NW=NWInt(c,100,EW(j),100,10);
    % Use 10-Points Legrend-Guass intergal rule with 100 nodes
    plot(EW(j),NW,'.g')
    hold on
end
XE=0.1:0.1:M;
Nv=0.5*(0.5*XE.*(1-c^2./XE)+c^2*log(c./sqrt(XE)));
% Analytic expression of the Wely's Law Nv
plot(XE,Nv,'.b')
title('N is red,Nv is blue,Nw is green,c=10')
xlabel('E')
ylabel('states<E')