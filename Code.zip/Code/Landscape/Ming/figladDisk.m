function figladDisk(c,K,N)
Z=zeros(N);
for i=1:N
    Z(i,:)=SGMLadDisk(c,K,(N-i)/N);
end
polar3d(Z,0,2*pi,0,1,1)
%title('c=100 K=1000')
    
