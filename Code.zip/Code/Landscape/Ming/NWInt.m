% Use P-points Legrend-Gauss intergral rule get the approximation N_w(E)
% K is the truncation terms in Lanscape U_K(r)
% Intergral mesh h=(b-a)/N;
function [NW]=NWInt(c,K,E,N,P)
% Find the integral domain from initial value r=0.1 and r=0.9
%a=findomain(c,K,E,0.1);
%b=findomain(c,K,E,0.9);
%a=Bifindomaina(c,K,E)
%b=Bifindomainb(c,K,E)
a=0;
b=1;
h=(b-a)/N;
T=a:h:b;
[X,W]=legslb(P);
% Get Legendre-Gauss-Lobatto points and weights
X=X';
W=W';
S=0;
for i=1:N
    Y=(T(i)+T(i+1)+h*X)/2;
    U=SGMLadDisk(c,K,Y);
    if min(U)>1/E
        UL=U;
    else
        I=find(U<1/E);
        U(I)=1/E;
        UL=U;
    end
    % Legendre-Gauss rule
    sw=0.5*W.*Y.*(E-1./UL);
    %sw=0.5*W.*Y./SGMLadDisk(c,K,Y);
    s=sum(sw);
    S=S+s;
end
%NW=(b^2-a^2)*E/4-h*S/2;
NW=h*S/2;