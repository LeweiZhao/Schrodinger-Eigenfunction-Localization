% Use Spectral-Glerkin method solve the Landscape U_k(r)
% truncation terms is K
function [u]=SGMLadDisk(c,K,r)
nr=length(r);
UK=zeros(nr,K);
for k=1:K
    [da,a]=japoly(k-1,1,c,2*r.^2-1);
    % computes the Jacobi polynomial
    UK(:,k)=(-1)^k*(2*k+c)*a/(k*(c/2+k-1)*(c/2+k)*(c/2+k+1));
    % Explicit expression of U_K(r)
end
SU=sum(UK,2)';
u=r.^c.*(r.^2-1)*c/8.*SU;

    