function figTunel(m1,m2,N)
C=linspace(0,1,N);
I=ones(1,N);
P=zeros(1,N);
for i=1:N
    P(i)=ProTunel(C(i),m1,m2);
end
plot(C,P)
hold on
Q=-log(P./(I-C));
plot(C,Q,'red')
xlabel('c')
ylabel('Probability')
title(' Quantum Tunneling')  