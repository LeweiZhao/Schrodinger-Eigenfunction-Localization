function figeigfun(c,m1,m2)
x=mineigen(c,m1,m2);
a=sqrt(x-m1);
b=sqrt(m2-x);
c1=sin(c*a)/(exp(-c*b)-exp((c-2)*b));
c2=-c1*exp(-2*b);
syms t y
y=sin(a*t);
ezplot(y,[0,c])
hold on
syms p q
q=c1*exp(-b*p)+c2*exp(b*p);
ezplot(q,[c,1])