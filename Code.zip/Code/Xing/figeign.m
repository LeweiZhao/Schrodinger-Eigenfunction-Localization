function figeign(c,m1,m2,N)
x=mineigen(c,m1,m2)
a=sqrt(x-m1);
b=sqrt(m2-x);
c1=sin(c*a)/(exp(-c*b)-exp((c-2)*b));
c2=-c1*exp(-2*b);
X1=linspace(0,c,c*N);
Y1=sin(a*X1);
plot(X1,Y1)
hold on
X2=linspace(c,1,(1-c)*N);
Y2=c1*exp(-b*X2)+c2*exp(b*X2);
plot(X2,Y2)