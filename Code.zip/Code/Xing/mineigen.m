function [x]=mineigen(c,m1,m2)
%x=(m1+m2)/2;
x=m1+1;
delta=1;
while abs(delta)>10^(-14)
 a=sqrt(x-m1);
 b=sqrt(m2-x);
 f=sin(c*a)*b*(exp(-c*b)+exp((c-2)*b))+cos(c*a)*a*(exp(-c*b)-exp((c-2)*b));
 df1=(c/2*b/a*cos(c*a)-sin(c*a)/(2*b))*(exp(-c*b)+exp((c-2)*b))+sin(c*a)*(c/2*exp(-c*b)-(c/2-1)*exp((c-2)*b));
 df2=(-c/2*sin(c*a)+cos(c*a)/(2*a))*(exp(-c*b)-exp((c-2)*b))+a/b*cos(c*a)*(c/2*exp(-c*b)+(c/2-1)*exp((c-2)*b));
 df=df1+df2;
 delta=df/f;
 x=x+delta;
end
x;