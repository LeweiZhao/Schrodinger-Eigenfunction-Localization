function [Uh]=xingode(N)
h=pi/(2*N);
T=linspace(0,pi/2,N+1);
x0=T(2:N);
D=eye(N-1);
Z=ones(N-2,1);
S1=-2*D+diag(Z,1)+diag(Z,-1);
S2=cot(x0)';
S3=D-diag(Z,-1);
x=x0';
l=zeros(N-1,1);
l(end)=pi;
J1=-2-h*cot(x);
J2=1+h*cot(x);
J3=J2(2:N-1);
J=diag(J1)+diag(Z,1)+diag(J3,-1);
dx=1;
while norm(dx)>10^(-9)
    x1=S3*x;
    F=S1*x-h*S2.*x1+h^2*cot(x)+l;
    JD=-h^2*csc(x).^2;
    JF=J+diag(JD);
    dx=JF\F;
    x=x-dx;
end
Uh=x;
plot(x0,Uh);