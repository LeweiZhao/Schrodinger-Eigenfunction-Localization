function [q]=pro1(c,m1,m2)
p=ProTunel(c,m1,m2)
a=p/(1-c)
q=log(p/(1-c));
%A=q/sqrt(m2);